### Hexlet tests and linter status:
[![Actions Status](https://github.com/Gamabyta24/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Gamabyta24/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/b0d62e5024f10bc85e42/maintainability)](https://codeclimate.com/github/Gamabyta24/python-project-49/maintainability)

[![asciicast](https://asciinema.org/a/SBSaIghLp1ctMN7xAMOoWPR3T.svg)](https://asciinema.org/a/SBSaIghLp1ctMN7xAMOoWPR3T)